import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import threading
import time
import subprocess
import decimal
from threading import Thread

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")
package_ok = 0

#global used to tell the worker thread the status of the window
windowopen  = True

def backgroundService():
    service = os.system("/usr/bin/python " + addonpath + "/resources/pidash-server.py " + addonpath)
    if service != 0:
	xbmcgui.Dialog().ok("Pidash-Server","$ADDON[service.pidash.server 30011]")

def backgroundThread():
    t1 = Thread( target=backgroundService)
    t1.setDaemon( True )
    t1.start()

def install_picamera():
    install = os.system("sudo apt-get install -f -y python-picamera")
    if install == 0:
	picamera_check = str.strip(subprocess.check_output("dpkg -l | awk '$2==\"python-picamera\" { print $3 }'", shell=True))
	xbmcgui.Dialog().ok("$ADDON[service.pidash.server 30006] ","$ADDON[service.pidash.server 30008] " + str(picamera_check))
	backgroundThread()
    else:
	xbmcgui.Dialog().ok("$ADDON[service.pidash.server 30004]","$ADDON[service.pidash.server 30005]")
	quit()

# versioncheck python-picamera
picamera_check = str.strip(subprocess.check_output("dpkg -l | awk '$2==\"python-picamera\" { print $3 }'", shell=True))
if picamera_check == "":
    dialog = xbmcgui.Dialog()
    ask = dialog.yesno("$ADDON[service.pidash.server 30000]","$ADDON[service.pidash.server 30001]")
    if ask == 1:
	install_picamera()
    else:
	xbmcgui.Dialog().ok("$ADDON[service.pidash.server 30009]","$ADDON[service.pidash.server 30010]")
	quit()

else:
    picamera_version = float(picamera_check)
    if picamera_version < 1.11:
	xbmcgui.Dialog().ok("$ADDON[service.pidash.server 30000]","$ADDON[service.pidash.server 30003] " + str(picamera_version),"\n$ADDON[service.pidash.server 30002]")
        install_picamera()
    else:
	backgroundThread()
