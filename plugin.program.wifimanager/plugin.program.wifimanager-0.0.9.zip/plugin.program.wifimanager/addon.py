import xbmc
import xbmcgui
import xbmcaddon
import commands
import time
import subprocess
import os
from threading import Thread
import hashlib

# Get global paths
addon = xbmcaddon.Addon(id='plugin.program.wifimanager')
addonpath = addon.getAddonInfo('path').decode("utf-8")
monitor=xbmc.Monitor()
desktop = xbmcgui.Window(10000)
hotspoterequirements = 0
kill = False
pause = False
updated = False
execute = False
timer = 28

#control
HOME_BUTTON  = 1201
BACK_BUTTON  = 1202
BUTTON_FOCUS = 1203
SETTINGS_BUTTON  = 1204
ACTION_BACK  = 92
NETWORK1_BUTTON  = 1205
NETWORK2_BUTTON  = 1206
NETWORK3_BUTTON  = 1207
NETWORK4_BUTTON  = 1208
WIFI_BUTTON  = 1209
APMODE_BUTTON  = 1210

# check os
if os.path.exists("/etc/os-release"):
    getos = str.strip(subprocess.check_output("sudo cat /etc/os-release | grep ^NAME=", shell=True)).replace('"','').split("=")
    if str(getos[1]) != "Raspbian GNU/Linux":
	xbmcgui.Dialog().ok("OS","$ADDON[plugin.program.wifimanager 30018]")
	quit()
else:
    xbmcgui.Dialog().ok("OS","$ADDON[plugin.program.wifimanager 30018]")
    quit()

desktop.setProperty('apmodepossible','false')

def cmd_exists(cmd):
    return subprocess.call("type " + cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE) == 0

def pkg_exists(cmd):
    check = str.strip(subprocess.check_output("dpkg -l | awk '$2==\"" + cmd + "\" { print $3 }'", shell=True))
    if check != "":
	return "ok"
    else:
	return "missing"

def check_md5(filePath):
    if os.path.exists(filePath):
	with open(filePath, 'rb') as fh:
    	    m = hashlib.md5()
    	    while True:
        	data = fh.read(8192)
        	if not data:
            	    break
        	m.update(data)
    	    return m.hexdigest()
    else:
	return "12345"

if cmd_exists("iwlist") == 0:
    xbmcgui.Dialog().ok("$ADDON[plugin.program.wifimanager 30007]","$ADDON[plugin.program.wifimanager 30008]")
    quit()

if cmd_exists("wpa_cli") == 0:
    xbmcgui.Dialog().ok("$ADDON[plugin.program.wifimanager 30007]","$ADDON[plugin.program.wifimanager 30009]")
    quit()

def checkInstall():

    global kill, pause, networklist, updated

    desktop.setProperty('hotspotssid',"")    
    apmodesetting = addon.getSetting('apmode')
    apmodessid = addon.getSetting('ssid')
    apmodepassword = addon.getSetting('password')
    os.system("sudo cp " + str(addonpath) + "/resources/lib/hostapd.master " + str(addonpath) + "/resources/lib/hostapd.conf")
    os.system("sed -i 's/ssid=CARPI/ssid=" + apmodessid + "/g' " + str(addonpath) + "/resources/lib/hostapd.conf")
    os.system("sed -i 's/wpa_passphrase=1234567890/wpa_passphrase=" + apmodepassword + "/g' " + str(addonpath) + "/resources/lib/hostapd.conf")
    desktop.setProperty('hotspotssid',str(apmodessid))

    if apmodesetting == "true":
	hostapdavailable = pkg_exists("hostapd")
	dnsmasqavailable = pkg_exists("dnsmasq")
	if check_md5('/etc/hostapd/hostapd.conf') == check_md5(str(addonpath) + "/resources/lib/hostapd.conf"):
	    md5hostapdcheck = "ok"
	else:
	    md5hostapdcheck = "fail"

	if check_md5('/etc/default/hostapd') == check_md5(str(addonpath) + "/resources/lib/hostapd"):
	    md5hostapddefaultcheck = "ok"
	else:
	    md5hostapddefaultcheck = "fail"

	if check_md5('/etc/dnsmasq.conf') == check_md5(str(addonpath) + "/resources/lib/dnsmasq.conf"):
	    md5dnsmasqcheck = "ok"
	else:
	    md5dnsmasqcheck = "fail"

	if hostapdavailable == "missing" or dnsmasqavailable == "missing"  or md5hostapdcheck == "fail" or md5hostapddefaultcheck == "fail" or md5dnsmasqcheck == "fail":
	    pause = True
	    ask = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30019]","$ADDON[plugin.program.wifimanager 30020]")
	else:
	    ask = 0

	if ask == 1:
	    inet = str.strip(subprocess.check_output('ping -c2 www.google.de >/dev/null 2>&1 || echo "fail"', shell=True))
	    desktop.setProperty('install','true')
	    if inet != "fail":
		desktop.setProperty('installmessage','[COLOR lightgreen]' + addon.getLocalizedString(30025) + '[/COLOR]')
		time.sleep(1)
		if hostapdavailable != "ok":
		    if updated == False:
			desktop.setProperty('installmessage',addon.getLocalizedString(30015))
			time.sleep(1)
			os.system("sudo apt-get update")
			updated = True
		    desktop.setProperty('installmessage',addon.getLocalizedString(30013))
		    os.system("sudo apt-get install --force-yes -q -f -y hostapd -o Dpkg::Options::=\"--force-confdef\" -o Dpkg::Options::=\"--force-confold\"")
		    if pkg_exists("hostapd") == "ok":
    			os.system("sudo update-rc.d hostapd disable")
			os.system("sudo cp " + str(addonpath) + "/resources/lib/hostapd.conf" + " /etc/hostapd/hostapd.conf")
			hostapdavailable = pkg_exists("hostapd")
		    else:
			xbmcgui.Dialog().ok("$ADDON[plugin.program.wifimanager 30007]","$ADDON[plugin.program.wifimanager 30011]")

		if dnsmasqavailable != "ok":
		    if updated == False:
			desktop.setProperty('installmessage',addon.getLocalizedString(30015))
			time.sleep(1)
			os.system("sudo apt-get update")
			updated = True
		    desktop.setProperty('installmessage',addon.getLocalizedString(30014))
		    time.sleep(1)
		    os.system("sudo apt-get install --force-yes -q -f -y dnsmasq -o Dpkg::Options::=\"--force-confdef\" -o Dpkg::Options::=\"--force-confold\"")
		    if pkg_exists("dnsmasq") == "ok":
			os.system("sudo update-rc.d dnsmasq disable")
			os.system("sudo cp " + str(addonpath) + "/resources/lib/dnsmasq.conf" + " /etc/dnsmasq.conf")
			dnsmasqavailable = pkg_exists("dnsmasq")
		    else:
			xbmcgui.Dialog().ok("$ADDON[plugin.program.wifimanager 30007]","$ADDON[plugin.program.wifimanager 30012]")
	    else:
		desktop.setProperty('installmessage','[COLOR red]' + addon.getLocalizedString(30026) + '[/COLOR]')
	    time.sleep(5)

	    if hostapdavailable == "ok" and md5hostapdcheck != "ok":
		desktop.setProperty('installmessage',addon.getLocalizedString(30027))
		time.sleep(1)
		os.system("sudo cp " + str(addonpath) + "/resources/lib/hostapd.conf" + " /etc/hostapd/hostapd.conf")
		if check_md5('/etc/hostapd/hostapd.conf') == check_md5(str(addonpath) + "/resources/lib/hostapd.conf"):
		    md5hostapdcheck = "ok"
		else:
		    md5hostapdcheck = "fail"
	    else:
		if check_md5('/etc/hostapd/hostapd.conf') == check_md5(str(addonpath) + "/resources/lib/hostapd.conf"):
		    md5hostapdcheck = "ok"
		else:
		    md5hostapdcheck = "fail"

	    if hostapdavailable == "ok" and md5hostapddefaultcheck != "ok":
		desktop.setProperty('installmessage',addon.getLocalizedString(30027))
		time.sleep(1)
		os.system("sudo cp " + str(addonpath) + "/resources/lib/hostapd" + " /etc/default/hostapd")
		if check_md5('/etc/default/hostapd') == check_md5(str(addonpath) + "/resources/lib/hostapd"):
		    md5hostapddefaultcheck = "ok"
		else:
		    md5hostapddefaultcheck = "fail"
	    else:
		if check_md5('/etc/default/hostapd') == check_md5(str(addonpath) + "/resources/lib/hostapd"):
		    md5hostapddefaultcheck = "ok"
		else:
		    md5hostapddefaultcheck = "fail"

	    if dnsmasqavailable == "ok" and md5dnsmasqcheck != "ok":
		desktop.setProperty('installmessage',addon.getLocalizedString(30028))
		time.sleep(1)
		os.system("sudo cp " + str(addonpath) + "/resources/lib/dnsmasq.conf" + " /etc/dnsmasq.conf")
		if check_md5('/etc/dnsmasq.conf') == check_md5(str(addonpath) + "/resources/lib/dnsmasq.conf"):
		    md5dnsmasqcheck = "ok"
		else:
		    md5dnsmasqcheck = "fail"
	    else:
		if check_md5('/etc/dnsmasq.conf') == check_md5(str(addonpath) + "/resources/lib/dnsmasq.conf"):
		    md5dnsmasqcheck = "ok"
		else:
		    md5dnsmasqcheck = "fail"

    if apmodesetting == "true" and hostapdavailable == "ok" and dnsmasqavailable == "ok" and md5hostapdcheck == "ok" and md5hostapddefaultcheck == "ok" and md5dnsmasqcheck == "ok":
	desktop.setProperty('apmodepossible','true')
	desktop.setProperty('install','false')
	desktop.setProperty('installmessage',"")
	pause = False
    else:
	desktop.setProperty('apmodepossible','false')
	desktop.setProperty('install','false')
	desktop.setProperty('installmessage',"")
	pause = False

def scanNetworks():
    global networklist
    checkif = subprocess.Popen(["sudo ifconfig | grep wlan | cut -d' ' -f1"], shell=True, stdout=subprocess.PIPE).stdout
    checkifresult = checkif.read().splitlines()
    checkhostapd = subprocess.Popen(["sudo ps -ax | grep hostapd | grep -v grep | cut -d? -f1"], shell=True, stdout=subprocess.PIPE).stdout
    checkdnsmasq = subprocess.Popen(["sudo ps -ax | grep dnsmasq | grep -v grep | cut -d? -f1"], shell=True, stdout=subprocess.PIPE).stdout
    checkhostapdstate = checkhostapd.read().splitlines()
    checkdnsmasqstate = checkdnsmasq.read().splitlines()
    if len(checkhostapdstate) > 0:
	desktop.setProperty('hostapdicon',"wifiman_icon_current.png")
    else:
	desktop.setProperty('hostapdicon',"wifiman_icon_disabled.png")

    if len(checkdnsmasqstate) > 0:
	desktop.setProperty('dnsmasqicon',"wifiman_icon_current.png")
    else:
	desktop.setProperty('dnsmasqicon',"wifiman_icon_disabled.png")

    if len(checkhostapdstate) > 0 and len(checkdnsmasqstate) > 0:
    	desktop.setProperty('storednet1',str(checkhostapdstate[0]).replace(" ",""))

    if str(checkifresult[0]) == "wlan0" and len(checkhostapdstate) == 0 and len(checkdnsmasqstate) == 0:
	desktop.setProperty('wifiavailable','true')
	desktop.setProperty('hostapdactive','false')
	desktop.setProperty('textcolor1',"white")
	desktop.setProperty('textcolor2',"white")
	desktop.setProperty('textcolor3',"white")
	desktop.setProperty('textcolor4',"white")
	desktop.setProperty('textcolor5',"white")
	desktop.setProperty('textcolor6',"white")
	desktop.setProperty('textcolor7',"white")
	desktop.setProperty('textcolor8',"white")

	desktop.setProperty('scanlist1',xbmc.getInfoLabel('$ADDON[plugin.program.wifimanager 30000]'))
	desktop.setProperty('scanlist2',"")
	desktop.setProperty('scanlist3',"")
	desktop.setProperty('scanlist4',"")
	desktop.setProperty('scanlist5',"")
	desktop.setProperty('scanlist6',"")
	desktop.setProperty('scanlist7',"")
	desktop.setProperty('scanlist8',"")

	status = commands.getstatusoutput('iwgetid -r')
	scanresult = subprocess.Popen(["sudo iwlist wlan0 scan | grep ESSID | cut -d: -f2"], shell=True, stdout=subprocess.PIPE).stdout
	getnetworks = subprocess.Popen(["sudo wpa_cli list_networks | grep any"], shell=True, stdout=subprocess.PIPE).stdout
	linescanresult = scanresult.read().splitlines()
	linegetnetworks = getnetworks.read().splitlines()
	count = 0

	for i in linegetnetworks:
	    count = count + 1
	    values = i.split("\t")
    	    desktop.setProperty('storednet' + str(int(values[0]) + 1),str(values[1]))
    	    desktop.setProperty('storedstate' + str(int(values[0]) + 1),str(values[3]))
	    if str(values[3]) == "[CURRENT]":
    		desktop.setProperty('storedneticon' + str(int(values[0]) + 1),"wifiman_icon_current.png")
		desktop.setProperty('showconfig' + str(int(values[0]) + 1),'true')
	    elif str(values[3]) == "[DISABLED]":
    		desktop.setProperty('storedneticon' + str(int(values[0]) + 1),"wifiman_icon_disabled.png")
		desktop.setProperty('showconfig' + str(int(values[0]) + 1),'true')
	    else:
    		desktop.setProperty('storedneticon' + str(int(values[0]) + 1),"wifiman_icon_ready.png")
		desktop.setProperty('showconfig' + str(int(values[0]) + 1),'true')

	if count == 0:
	    desktop.setProperty('showconfig1','true')
	    desktop.setProperty('storednet1',"")
	    desktop.setProperty('storedstate1',"")
	    desktop.setProperty('storedneticon1',"")
	    desktop.setProperty('showconfig2','false')
	    desktop.setProperty('storednet2',"")
	    desktop.setProperty('storedstate2',"")
	    desktop.setProperty('storedneticon2',"")
	    desktop.setProperty('showconfig3','false')
	    desktop.setProperty('storednet3',"")
	    desktop.setProperty('storedstate3',"")
	    desktop.setProperty('storedneticon3',"")
	    desktop.setProperty('showconfig4','false')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	if count == 1:
	    desktop.setProperty('showconfig2','true')
	    desktop.setProperty('storednet2',"")
	    desktop.setProperty('storedstate2',"")
	    desktop.setProperty('storedneticon2',"")
	    desktop.setProperty('showconfig3','false')
	    desktop.setProperty('storednet3',"")
	    desktop.setProperty('storedstate3',"")
	    desktop.setProperty('storedneticon3',"")
	    desktop.setProperty('showconfig4','false')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	if count == 2:
	    desktop.setProperty('showconfig3','true')
	    desktop.setProperty('storednet3',"")
	    desktop.setProperty('storedstate3',"")
	    desktop.setProperty('storedneticon3',"")
	    desktop.setProperty('showconfig4','false')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	if count == 3:
	    desktop.setProperty('showconfig4','true')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	count = 1
	networklist = ['[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]','[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]','[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]','[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]','']
	for i in linescanresult:
	    i = str(i.replace('"',''))
	    if i != "":
		if str(i) == str(status[1]):
		    desktop.setProperty('textcolor' + str(count),"lightgreen")
		desktop.setProperty('scanlist' + str(count),str(count) + ': ' + i)
		networklist.append(str(i))
		count = count + 1
	networklist = tuple(networklist)

    else:
	if str(checkifresult[0]) != "wlan0" and len(checkhostapdstate) == 0 and len(checkdnsmasqstate) == 0:
	    desktop.setProperty('wifiavailable','false')
	    desktop.setProperty('hostapdactive','false')
	    desktop.setProperty('scanlist1',"")
	    desktop.setProperty('scanlist2',"")
	    desktop.setProperty('scanlist3',"")
	    desktop.setProperty('scanlist4',"")
	    desktop.setProperty('scanlist5',"")
	    desktop.setProperty('scanlist6',"")
	    desktop.setProperty('scanlist7',"")
	    desktop.setProperty('scanlist8',"")
	    desktop.setProperty('showconfig1','false')
	    desktop.setProperty('storednet1',"")
	    desktop.setProperty('storedstate1',"")
	    desktop.setProperty('storedneticon1',"")
	    desktop.setProperty('showconfig2','false')
	    desktop.setProperty('storednet2',"")
	    desktop.setProperty('storedstate2',"")
	    desktop.setProperty('storedneticon2',"")
	    desktop.setProperty('showconfig3','false')
	    desktop.setProperty('storednet3',"")
	    desktop.setProperty('storedstate3',"")
	    desktop.setProperty('storedneticon3',"")
	    desktop.setProperty('showconfig4','false')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	if str(checkifresult[0]) == "wlan0" and len(checkhostapdstate) != 0 and len(checkdnsmasqstate) != 0:
	    desktop.setProperty('wifiavailable','false')
	    desktop.setProperty('hostapdactive','true')
	    desktop.setProperty('scanlist1',"")
	    desktop.setProperty('scanlist2',"")
	    desktop.setProperty('scanlist3',"")
	    desktop.setProperty('scanlist4',"")
	    desktop.setProperty('scanlist5',"")
	    desktop.setProperty('scanlist6',"")
	    desktop.setProperty('scanlist7',"")
	    desktop.setProperty('scanlist8',"")
	    desktop.setProperty('showconfig1','false')
	    desktop.setProperty('storednet1',"")
	    desktop.setProperty('storedstate1',"")
	    desktop.setProperty('storedneticon1',"")
	    desktop.setProperty('showconfig2','false')
	    desktop.setProperty('storednet2',"")
	    desktop.setProperty('storedstate2',"")
	    desktop.setProperty('storedneticon2',"")
	    desktop.setProperty('showconfig3','false')
	    desktop.setProperty('storednet3',"")
	    desktop.setProperty('storedstate3',"")
	    desktop.setProperty('storedneticon3',"")
	    desktop.setProperty('showconfig4','false')
	    desktop.setProperty('storednet4',"")
	    desktop.setProperty('storedstate4',"")
	    desktop.setProperty('storedneticon4',"")

	    getclients = subprocess.Popen(["sudo cat /var/lib/misc/dnsmasq.leases"], shell=True, stdout=subprocess.PIPE).stdout
	    lineclientresult = getclients.read().splitlines()
	    count = 1
	    if len(lineclientresult) > 0:
		for i in lineclientresult:
		    values = i.split(" ")
		    response = os.system("ping -c1 -t250 " + str(values[2]))
		    if response == 0:
			desktop.setProperty('clientip' + str(count),str(values[3]))
			desktop.setProperty('client' + str(count),str(values[2]))
			count = count + 1
	    while count <= 7:
		desktop.setProperty('clientip' + str(count),'')
		desktop.setProperty('client' + str(count),'')
		count = count + 1
    desktop.setProperty('switching','false')

def autoScan():
    global timer

    while True:
	if pause != True:
	    timer = timer + 1
	    if timer > 30:
		scanNetworks()
		timer = 0
	time.sleep(0.5)
	if kill == True:
	    break

t1 = Thread( target=autoScan)
t1.setDaemon( True )
t1.start()

class wifimanager(xbmcgui.WindowXMLDialog):

    def onInit(self):
        wifimanager.button_home=self.getControl(HOME_BUTTON)
        wifimanager.button_back=self.getControl(BACK_BUTTON)
        wifimanager.buttonfocus=self.getControl(BUTTON_FOCUS)
        wifimanager.buttonwifi=self.getControl(WIFI_BUTTON)
        wifimanager.buttonapmode=self.getControl(APMODE_BUTTON)
        wifimanager.button_settings=self.getControl(SETTINGS_BUTTON)
	desktop.setProperty('switching','false')
	checkInstall()

    def onAction(self, action):
        pass
        
    def onClick(self, controlID):

	global kill, pause, networklist, execute

        if controlID == HOME_BUTTON:
	    kill = True
	    time.sleep(0.3)
            self.close()

        if controlID == BACK_BUTTON:
	    kill = True
	    time.sleep(0.3)
            self.close()

        if controlID == SETTINGS_BUTTON:
	    self.setFocus(self.buttonfocus)
	    pause = True
	    addon.openSettings()
	    checkInstall()
	    pause = False
	    self.setFocus(self.buttonfocus)

        if controlID == NETWORK1_BUTTON:
	    pause = True
	    check = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30001]","$ADDON[plugin.program.wifimanager 30002]")
	    if check == 1:
		selected = xbmcgui.Dialog().select("$ADDON[plugin.program.wifimanager 30003]",networklist)
		if  networklist[selected] != "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]" and networklist[selected] != "" and selected != -1:
		    password = xbmcgui.Dialog().input("$ADDON[plugin.program.wifimanager 30004]")
		    if password != "":
			os.system("sudo wpa_cli remove_network 0")
			os.system("sudo wpa_cli add_network 0")
			os.system("sudo wpa_cli set_network 0 ssid '\"" + networklist[selected] + "\"'")
			os.system("sudo wpa_cli set_network 0 psk '\"" + password + "\"'")
			os.system("sudo wpa_cli enable_network 0")
			os.system("sudo wpa_cli save")
			desktop.setProperty('storednet1',"...")
		if networklist[selected] == "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]":
			really = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30029]","$ADDON[plugin.program.wifimanager 30030]")
			if really == 1:
			    os.system("sudo wpa_cli remove_network 0")
			    os.system("sudo wpa_cli save")
			    desktop.setProperty('showconfig1','false')
			    desktop.setProperty('storednet1',"")
			    desktop.setProperty('storedstate1',"")
			    desktop.setProperty('storedneticon1',"")
			    os.system("sudo wpa_cli reconfigure")
		if networklist[selected] == "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli enable_network 0")
		if networklist[selected] == "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli disable_network 0")
		if networklist[selected] == "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli select_network 0")
	    timer = 30
	    pause = False

        if controlID == NETWORK2_BUTTON:
	    pause = True
	    check = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30001]","$ADDON[plugin.program.wifimanager 30002]")
	    if check == 1:
		selected = xbmcgui.Dialog().select("$ADDON[plugin.program.wifimanager 30003]",networklist)
		if  networklist[selected] != "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]" and networklist[selected] != "" and selected != -1:
		    password = xbmcgui.Dialog().input("$ADDON[plugin.program.wifimanager 30004]")
		    if password != "":
			os.system("sudo wpa_cli remove_network 1")
			os.system("sudo wpa_cli add_network 1")
			os.system("sudo wpa_cli set_network 1 ssid '\"" + networklist[selected] + "\"'")
			os.system("sudo wpa_cli set_network 1 psk '\"" + password + "\"'")
			os.system("sudo wpa_cli enable_network 1")
			os.system("sudo wpa_cli save")
			desktop.setProperty('storednet2',"...")
		if networklist[selected] == "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]":
			really = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30029]","$ADDON[plugin.program.wifimanager 30030]")
			if really == 1:
			    os.system("sudo wpa_cli remove_network 1")
			    os.system("sudo wpa_cli save")
			    desktop.setProperty('showconfig2','false')
			    desktop.setProperty('storednet2',"")
			    desktop.setProperty('storedstate2',"")
			    desktop.setProperty('storedneticon2',"")
			    os.system("sudo wpa_cli reconfigure")
		if networklist[selected] == "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli enable_network 1")
		if networklist[selected] == "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli disable_network 1")
		if networklist[selected] == "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli select_network 1")
	    timer = 30
	    pause = False

        if controlID == NETWORK3_BUTTON:
	    pause = True
	    check = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30001]","$ADDON[plugin.program.wifimanager 30002]")
	    if check == 1:
		selected = xbmcgui.Dialog().select("$ADDON[plugin.program.wifimanager 30003]",networklist)
		if  networklist[selected] != "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]" and networklist[selected] != "" and selected != -1:
		    password = xbmcgui.Dialog().input("$ADDON[plugin.program.wifimanager 30004]")
		    if password != "":
			os.system("sudo wpa_cli remove_network 2")
			os.system("sudo wpa_cli add_network 2")
			os.system("sudo wpa_cli set_network 2 ssid '\"" + networklist[selected] + "\"'")
			os.system("sudo wpa_cli set_network 2 psk '\"" + password + "\"'")
			os.system("sudo wpa_cli enable_network 2")
			os.system("sudo wpa_cli save")
			desktop.setProperty('storednet3',"...")
		if networklist[selected] == "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]":
			really = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30029]","$ADDON[plugin.program.wifimanager 30030]")
			if really == 1:
			    os.system("sudo wpa_cli remove_network 2")
			    os.system("sudo wpa_cli save")
			    desktop.setProperty('showconfig3','false')
			    desktop.setProperty('storednet3',"")
			    desktop.setProperty('storedstate3',"")
			    desktop.setProperty('storedneticon3',"")
			    os.system("sudo wpa_cli reconfigure")
		if networklist[selected] == "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli enable_network 2")
			scanNetworks()
		if networklist[selected] == "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli disable_network 2")
		if networklist[selected] == "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli select_network 2")
	    timer = 30
	    pause = False

        if controlID == NETWORK4_BUTTON:
	    pause = True
	    check = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30001]","$ADDON[plugin.program.wifimanager 30002]")
	    if check == 1:
		selected = xbmcgui.Dialog().select("$ADDON[plugin.program.wifimanager 30003]",networklist)
		if  networklist[selected] != "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]" and networklist[selected] != "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]" and networklist[selected] != "" and selected != -1:
		    password = xbmcgui.Dialog().input("$ADDON[plugin.program.wifimanager 30004]")
		    if password != "":
			os.system("sudo wpa_cli remove_network 3")
			os.system("sudo wpa_cli add_network 3")
			os.system("sudo wpa_cli set_network 3 ssid '\"" + networklist[selected] + "\"'")
			os.system("sudo wpa_cli set_network 3 psk '\"" + password + "\"'")
			os.system("sudo wpa_cli enable_network 3")
			os.system("sudo wpa_cli save")
			desktop.setProperty('storednet4',"...")
		if networklist[selected] == "[COLOR red][B]>>> DELETE NETWORK <<<[/B][/COLOR]":
			really = xbmcgui.Dialog().yesno("$ADDON[plugin.program.wifimanager 30029]","$ADDON[plugin.program.wifimanager 30030]")
			if really == 1:
			    os.system("sudo wpa_cli remove_network 3")
			    os.system("sudo wpa_cli save")
			    desktop.setProperty('storednet4',"...")
			    desktop.setProperty('storedstate4',"")
			    desktop.setProperty('storedneticon4',"")
			    os.system("sudo wpa_cli reconfigure")
		if networklist[selected] == "[COLOR lightgreen][B]>>> ENABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli enable_network 3")
		if networklist[selected] == "[COLOR orange][B]>>> DISABLE NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli disable_network 3")
		if networklist[selected] == "[COLOR blue][B]>>> SELECT NETWORK <<<[/B][/COLOR]":
			os.system("sudo wpa_cli select_network 3")
	    timer = 30
	    pause = False

        if controlID == WIFI_BUTTON:
	    pause = True
	    self.setFocus(self.buttonfocus)
	    desktop.setProperty('switching','true')
	    time.sleep(1)
	    if execute == False:
		execcute = True
		os.system("sudo chmod 777 " + str(addonpath) + "/resources/lib/enablewifi")
		os.system("sudo " + str(addonpath) + "/resources/lib/enablewifi")
		time.sleep(5)
		pause = False
		execute = False

        if controlID == APMODE_BUTTON:
	    pause = True
	    self.setFocus(self.buttonfocus)
	    desktop.setProperty('switching','true')
	    time.sleep(1)
	    if execute == False:
		execcute = True
		os.system("sudo chmod 777 " + str(addonpath) + "/resources/lib/enableapmode")
		os.system("sudo " + str(addonpath) + "/resources/lib/enableapmode")
		time.sleep(5)
		pause = False
		execute = False

    def onFocus(self, controlID):
        pass
    
    def onControl(self, controlID):
        pass

wifimanagerdialog = wifimanager("wifimanager.xml", addonpath, 'default', '720')
wifimanagerdialog.doModal()
del wifimanagerdialog

