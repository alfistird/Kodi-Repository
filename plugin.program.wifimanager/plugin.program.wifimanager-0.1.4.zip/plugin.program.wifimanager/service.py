import xbmc
import xbmcgui
import xbmcaddon
import time
import os

# Get global paths
addon = xbmcaddon.Addon(id='plugin.program.wifimanager')
addonpath = addon.getAddonInfo('path').decode("utf-8")
desktop = xbmcgui.Window(10000)
autostart = addon.getSetting('apmodestartup')

if autostart == "true":
    desktop.setProperty('switching','true')
    time.sleep(1)
    desktop.setProperty('wifiavailable','false')
    realtek = addon.getSetting('realtek')
    if realtek == "true":
        os.system("sudo cp " + str(addonpath) + "/resources/lib/modrealtek/hostapd" + str(addonpath) + "/usr/sbin/hostapd")
        os.system("sudo cp " + str(addonpath) + "/resources/lib/modrealtek/hostapd_cli" + str(addonpath) + "/usr/sbin/hostapd_cli")
        os.system("sudo chmod 777 /usr/sbin/hostapd")
        os.system("sudo chmod 777 /usr/sbin/hostapd_cli")
    else:
        os.system("sudo cp " + str(addonpath) + "/resources/lib/raspbian/hostapd" + str(addonpath) + "/usr/sbin/hostapd")
        os.system("sudo cp " + str(addonpath) + "/resources/lib/raspbian/hostapd_cli" + str(addonpath) + "/usr/sbin/hostapd_cli")
        os.system("sudo chmod 777 /usr/sbin/hostapd")
        os.system("sudo chmod 777 /usr/sbin/hostapd_cli")
    os.system("sudo chmod 777 " + str(addonpath) + "/resources/lib/enableapmode")
    os.system("sudo " + str(addonpath) + "/resources/lib/enableapmode")
    desktop.setProperty('hostapdactive','true')
