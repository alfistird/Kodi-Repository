import xbmc
import xbmcgui
import xbmcaddon
import time
import os

# Get global paths
addon = xbmcaddon.Addon(id='plugin.program.wifimanager')
addonpath = addon.getAddonInfo('path').decode("utf-8")
desktop = xbmcgui.Window(10000)
autostart = addon.getSetting('apmodestartup')

os.system("sudo /sbin/ifdown eth0")

if autostart == "true":
    desktop.setProperty('switching','true')
    time.sleep(1)
    desktop.setProperty('wifiavailable','false')
    realtek = addon.getSetting('realtek')
    if realtek == "true":
	os.system("sudo cp " + str(addonpath) + "/resources/lib/modrealtek/hostapd /usr/sbin/hostapd")
	os.system("sudo cp " + str(addonpath) + "/resources/lib/modrealtek/hostapd_cli /usr/sbin/hostapd_cli")
	os.system("sudo chmod 777 /usr/sbin/hostapd")
	os.system("sudo chmod 777 /usr/sbin/hostapd_cli")

    else:
	os.system("sudo cp " + str(addonpath) + "/resources/lib/raspbian/hostapd /usr/sbin/hostapd")
	os.system("sudo cp " + str(addonpath) + "/resources/lib/raspbian/hostapd_cli /usr/sbin/hostapd_cli")
	os.system("sudo chmod 777 /usr/sbin/hostapd")
	os.system("sudo chmod 777 /usr/sbin/hostapd_cli")

    os.system("sudo /sbin/ifdown wlan0")
    os.system("sudo /sbin/ifconfig wlan0 10.0.0.1 netmask 255.255.255.0 up")
    os.system("sudo /etc/init.d/hostapd start")
    os.system("sudo /etc/init.d/dnsmasq start")
    desktop.setProperty('hostapdactive','true')