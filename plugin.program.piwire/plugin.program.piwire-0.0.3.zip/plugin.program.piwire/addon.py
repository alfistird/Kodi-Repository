import calendar
import datetime
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import socket
import threading
import time
import subprocess
import decimal
import subprocess
import datetime as dt
from threading import Thread

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")

#control
HOME_BUTTON  = 1201
BACK_BUTTON  = 1202
BUTTON_FOCUS = 1203
SETTINGS_BUTTON  = 1204
ACTION_BACK  = 92

# Init values from addon settings
#xbmcgui.Window(10000).setProperty('LiveviewControls',addon.getSetting('LiveviewControls'))

def updateSettings():
    xbmcgui.Window(10000).setProperty('sensor1',addon.getSetting('sensor1'))
    xbmcgui.Window(10000).setProperty('sensor2',addon.getSetting('sensor2'))
    xbmcgui.Window(10000).setProperty('sensor3',addon.getSetting('sensor3'))
    xbmcgui.Window(10000).setProperty('sensor4',addon.getSetting('sensor4'))
    xbmcgui.Window(10000).setProperty('sensor5',addon.getSetting('sensor5'))
    xbmcgui.Window(10000).setProperty('sensor6',addon.getSetting('sensor6'))
    xbmcgui.Window(10000).setProperty('sensor7',addon.getSetting('sensor7'))
    xbmcgui.Window(10000).setProperty('sensor8',addon.getSetting('sensor8'))
    xbmcgui.Window(10000).setProperty('showsensor1',addon.getSetting('showsensor1'))
    xbmcgui.Window(10000).setProperty('showsensor2',addon.getSetting('showsensor2'))
    xbmcgui.Window(10000).setProperty('showsensor3',addon.getSetting('showsensor3'))
    xbmcgui.Window(10000).setProperty('showsensor4',addon.getSetting('showsensor4'))
    xbmcgui.Window(10000).setProperty('showsensor5',addon.getSetting('showsensor5'))
    xbmcgui.Window(10000).setProperty('showsensor6',addon.getSetting('showsensor6'))
    xbmcgui.Window(10000).setProperty('showsensor7',addon.getSetting('showsensor7'))
    xbmcgui.Window(10000).setProperty('showsensor8',addon.getSetting('showsensor8'))

updateSettings()

class piwire(xbmcgui.WindowXMLDialog):

    def onInit(self):
        piwire.button_home=self.getControl(HOME_BUTTON)
        piwire.button_back=self.getControl(BACK_BUTTON)
        piwire.buttonfocus=self.getControl(BUTTON_FOCUS)
        piwire.button_settings=self.getControl(SETTINGS_BUTTON)

    def onAction(self, action):
        global windowopen
        
    def onClick(self, controlID):

        if controlID == HOME_BUTTON:
            self.close()

        if controlID == BACK_BUTTON:
            self.close()

        if controlID == SETTINGS_BUTTON:
	    self.setFocus(self.buttonfocus)
	    addon.openSettings()
	    updateSettings()
	    self.setFocus(self.buttonfocus)

    def onFocus(self, controlID):
        pass
    
    def onControl(self, controlID):
        pass
 
onewiredialog = piwire("onewire.xml", addonpath, 'default', '720')

onewiredialog.doModal()
del onewiredialog
