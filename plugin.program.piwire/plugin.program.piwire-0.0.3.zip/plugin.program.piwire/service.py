#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import time
import decimal

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")
monitor=xbmc.Monitor()

# Defaults
counter = 15
xbmcgui.Window(10000).setProperty('Temp1','n/a')
xbmcgui.Window(10000).setProperty('Temp2','n/a')
xbmcgui.Window(10000).setProperty('Temp3','n/a')
xbmcgui.Window(10000).setProperty('Temp4','n/a')
xbmcgui.Window(10000).setProperty('Temp5','n/a')
xbmcgui.Window(10000).setProperty('Temp6','n/a')
xbmcgui.Window(10000).setProperty('Temp7','n/a')
xbmcgui.Window(10000).setProperty('Temp8','n/a')

def readSensors():
    #sensorlist = ""
    linenumber = 1
    file = open('/sys/devices/w1_bus_master1/w1_master_slaves')
    w1_slaves = file.readlines()
    file.close()
    for line in w1_slaves:
	w1_slave = line.split("\n")[0]
	file = open('/sys/bus/w1/devices/' + str(w1_slave) + '/w1_slave')
	filecontent = file.read()
	file.close()
	if "YES" in filecontent:
	    stringvalue = filecontent.split("\n")[1].split(" ")[9]
    	    temperaturefull = float(stringvalue[2:]) / 1000
    	    temperature = round(temperaturefull,1)
	    tempold = str(xbmcgui.Window(10000).getProperty('Temp' + str(linenumber)))
    	    if tempold == "n/a" or tempold == "error":
		tempold = temperature
    	    else:
		tempold = float(tempold)
    	    if temperature > tempold:
		xbmcgui.Window(10000).setProperty('Trend' + str(linenumber),'piwire_icon_up.png')
    	    if temperature < tempold:
		xbmcgui.Window(10000).setProperty('Trend' + str(linenumber),'piwire_icon_down.png')
    	    if temperature == tempold:
		xbmcgui.Window(10000).setProperty('Trend' + str(linenumber),'piwire_dummy.png')
	    xbmcgui.Window(10000).setProperty('Temp' + str(linenumber),str(temperature))
    	    #sensorlist = sensorlist + w1_slave + "|"
	    #addon.setSetting('sensors',str(sensorlist))
	else:
	    xbmcgui.Window(10000).setProperty('Temp' + str(linenumber),"n/a")
	    xbmcgui.Window(10000).setProperty('Trend' + str(linenumber),'piwire_icon_warning.png')
	    if addon.getSetting('sensormissing') == "true":
        	xbmcgui.Dialog().ok("$ADDON[plugin.program.piwire 30020]","$ADDON[plugin.program.piwire 30022]")

	linenumber = linenumber + 1

readSensors()

while True:
    if monitor.abortRequested():
	break
    counter = counter - 1
    if counter <= 0:
	counter = 15
	readSensors()
    time.sleep(1.0)

quit()


