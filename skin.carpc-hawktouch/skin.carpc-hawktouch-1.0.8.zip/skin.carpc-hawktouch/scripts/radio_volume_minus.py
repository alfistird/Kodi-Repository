import calendar
import datetime
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import socket
import threading
import time

def CarpcController_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Send request to server
        sock.sendto(command + "\0", (UDP_IP, UDP_PORT))

        sock.close()

def Radio_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Send request to server
        sock.sendto("radio_" + command + "\0", (UDP_IP, UDP_PORT))

        sock.close()

if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "true":
	Radio_SendCommand("volume_minus")
