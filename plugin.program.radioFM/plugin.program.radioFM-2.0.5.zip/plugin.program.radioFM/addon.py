import calendar
import datetime
import sys
import os
import xbmc
import xbmcgui
import xbmcaddon
import socket
import threading
import time
import subprocess
import decimal
from threading import Thread

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")

# Open socket for communication with the gpio-manager UDP server
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#control
HOME_BUTTON  = 1101
BACK_BUTTON  = 1102
BUTTON_FOCUS = 1103
TUNE_UP = 1104
TUNE_DOWN = 1105
SEEK_UP = 1106
SEEK_DOWN = 1107
VOLUME_UP = 1108
VOLUME_DOWN = 1109
STORE_BUTTON = 1110
DELETE_BUTTON = 1111
STATIONS_BUTTON = 1112
MUTE_BUTTON = 1113
SETTINGS_BUTTON = 1114
VOLUME_XBMC = 1
STA1_BUTTON = 1121
STA2_BUTTON = 1122
STA3_BUTTON = 1123
STA4_BUTTON = 1124
STA5_BUTTON = 1125
STA6_BUTTON = 1126
STA7_BUTTON = 1127
STA8_BUTTON = 1128
STA9_BUTTON = 1129
STA10_BUTTON = 1130

ACTION_BACK  = 92

#global used to tell the worker thread the status of the window
windowopen  = True



def updateWindow():
    global mute

    while windowopen and (not xbmc.abortRequested):

        vcheckdb = xbmc.getInfoLabel('Player.Volume')
	vchecksplit = vcheckdb.split(' ')
	vchecktemp = vchecksplit[0]
	vcheck = int(float(vchecktemp)) * -1

	if vcheck <= 56 and vcheck >= 0:
	    xbmc.executebuiltin('Skin.SetBool(MuteVolume,True)')
	    mute = 1

	if vcheck >= 56:
	    xbmc.executebuiltin('Skin.SetBool(MuteVolume,False)')
	    mute = 0

	if str(addon.getSetting('ShowStationLogos')) == "true":
	    radiofreqlogo = xbmcgui.Window(10000).getProperty('Radio.Frequency')
    	    defaultlogopath = addon.getSetting('StationLogosPath')
    	    radiologo = defaultlogopath + radiofreqlogo + ".png"
	    if os.path.isfile(radiologo) == True:
        	xbmcgui.Window(10000).setProperty('Radio.StationLogo',radiologo)
	    else:
        	xbmcgui.Window(10000).setProperty('Radio.StationLogo','radio_icon_logo.png')
	else:
	    xbmcgui.Window(10000).setProperty('Radio.StationLogo','radio_icon_logo.png')

        # give us a break
        time.sleep(1.0)

def CarpcController_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Send request to server
        sock.sendto(command + "\0", (UDP_IP, UDP_PORT))

def Radio_SendCommand(self, command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        # Send request to server
        sock.sendto("radio_" + command + "\0", (UDP_IP, UDP_PORT))

def Init_Values():
	    stationloop = 1
	    while True:
		checkfreq = addon.getSetting('Station' + str(stationloop) + '_Freq')
		checkname = addon.getSetting('Station' + str(stationloop))
		if checkfreq != "" and checkname != "- - -":
		    NewStationString = checkfreq + " - " + checkname
		    xbmc.executebuiltin('Skin.SetString(Station' + str(stationloop) + ',' + NewStationString + ')')
	        stationloop = stationloop + 1
	        if stationloop > 10:
		    break

	    stationloop = 1
	    while True:
		checkfreq = addon.getSetting('Station' + str(stationloop) + 'b_Freq')
		checkname = addon.getSetting('Station' + str(stationloop) + 'b')
		if checkfreq != "" and checkname != "- - -":
		    NewStationString = checkfreq + " - " + checkname
		    xbmc.executebuiltin('Skin.SetString(Station' + str(stationloop) + 'b,' + NewStationString + ')')
	        stationloop = stationloop + 1
	        if stationloop > 10:
		    break

	    stationloop = 1
	    while True:
    		station = str(xbmc.getInfoLabel('Skin.String(Station' + str(stationloop) + ')'))
		if station == "":
		    xbmc.executebuiltin('Skin.SetString(station' + str(stationloop) + ',- - -)')
	        stationloop = stationloop + 1
	        if stationloop > 10:
		    break

	    stationloop = 1
	    while True:
    		station = str(xbmc.getInfoLabel('Skin.String(Station' + str(stationloop) + 'b)'))
		if station == "":
		    xbmc.executebuiltin('Skin.SetString(station' + str(stationloop) + 'b,- - -)')
	        stationloop = stationloop + 1
	        if stationloop > 10:
		    break

	    bgimage = addon.getSetting('custombackgroundimage')
	    setbgimage = str(addon.getSetting('custombackground'))
	    if setbgimage == "true":
		xbmc.executebuiltin('Skin.SetString(RadioAddonBackgroundImage,' + bgimage + ')')
	    else:
		xbmc.executebuiltin('Skin.SetString(RadioAddonBackgroundImage,radiodefault.jpg)')

	    #xbmcgui.Window(10000).setProperty('Radio.ShowStationLogo',addon.getSetting('ShowStationLogos'))

# Set default Values for Stations with empty value
Init_Values()

def Tune_Station(self, command):
        storemode = str(xbmc.getCondVisibility('Skin.HasSetting(SaveRadioStation)'))
        delmode = str(xbmc.getCondVisibility('Skin.HasSetting(DeleteRadioStation)'))
        radiolist = str(xbmc.getCondVisibility('Skin.HasSetting(ListRadioStation)'))
        if radiolist == "0" :
	    command = command + 'b'

        if storemode == "1" and delmode == "1": # check of store or delmode active

	    station = str(xbmc.getInfoLabel('Skin.String(' + command + ')'))
            requestedFrequency = station.split(' ')
            if str(requestedFrequency[0]) != "-":
		Radio_SendCommand(self, "tune_" + requestedFrequency[0])
                if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
	                xbmc.Player().stop()
    	                CarpcController_SendCommand("system_mode_toggle")

def Cleanup_Station(self, command):
        storemode = str(xbmc.getCondVisibility('Skin.HasSetting(SaveRadioStation)'))
        delmode = str(xbmc.getCondVisibility('Skin.HasSetting(DeleteRadioStation)'))
        radiolist = str(xbmc.getCondVisibility('Skin.HasSetting(ListRadioStation)'))
        if radiolist == "0" :
	    command = command + 'b'
	commandfreq = command + '_Freq'

        if storemode == "1" and delmode == "1": # check of store or delmode active

	    station = str(xbmc.getInfoLabel('Skin.String(' + command + ')'))
            stationString = station.split('-')
            #xbmcgui.Dialog().ok("Testing",str(stationString[0] + " - " + stationString[1]))
	    stationName = str.strip(stationString[1])
	    stationFrequency = str.strip(stationString[0])

	    if stationName == "":
	    	stationName = "Unknown"
	    if stationFrequency == "":
	    	stationName = "- - -"
		xbmc.executebuiltin('Skin.SetString(' + command + ',- - -)')
	    else:
		NewStationString = stationFrequency + " - " + stationName
		xbmc.executebuiltin('Skin.SetString(' + command + ',' + NewStationString + ')')

	    addon.setSetting(command,stationName)
	    addon.setSetting(commandfreq,stationFrequency)

def Radio_Mute(self):
	    
	    global mute	    
	    if str(mute) == "1":
		volumedb = xbmc.getInfoLabel('Player.Volume')
        	volumesplit = volumedb.split(' ')
		volumetemp = volumesplit[0]
		volume = int(float(volumetemp)) * -1
		volumeradio = 0

		if volume <= 60 and volume > 56:
		    volumeradio = 0
		if volume <= 56 and volume > 52:
		    volumeradio = 2
		if volume <= 52 and volume > 48:
		    volumeradio = 3
		if volume <= 48 and volume > 44:
		    volumeradio = 4
		if volume <= 44 and volume > 40:
		    volumeradio = 5
		if volume <= 40 and volume > 36:
		    volumeradio = 6
		if volume <= 36 and volume > 32:
		    volumeradio = 7
		if volume <= 32 and volume > 28:
		    volumeradio = 8
		if volume <= 28 and volume > 24:
		    volumeradio = 9
		if volume <= 24 and volume > 20:
		    volumeradio = 10
		if volume <= 20 and volume > 16:
		    volumeradio = 11
		if volume <= 16 and volume > 12:
		    volumeradio = 12
		if volume <= 12 and volume > 8:
		    volumeradio = 13
		if volume <= 8 and volume > 4:
		    volumeradio = 14
		if volume <= 4 and volume > 0:
		    volumeradio = 15
		xbmc.executebuiltin('Skin.SetString(StoredVolume,' + str(volumeradio) + ')')
		storedvolume = volumeradio
		while True:
	            Radio_SendCommand(self,"volume_minus")
		    storedvolume = storedvolume - 1
		    if storedvolume <= 0:
		        break
		mute = 1

	    else:
        	storedvolume = str(xbmc.getInfoLabel('Skin.String("StoredVolume")'))
		counter = int(storedvolume)
		while True:
	            Radio_SendCommand(self,"volume_plus")
		    counter = counter - 1
		    if counter <= 0:
		        break
		mute = 0

class radiofm(xbmcgui.WindowXMLDialog):

    def onInit(self):
        radiofm.button_home=self.getControl(HOME_BUTTON)
        radiofm.button_back=self.getControl(BACK_BUTTON)
        radiofm.buttonfocus=self.getControl(BUTTON_FOCUS)

    def onAction(self, action):
        global windowopen
        
    def onClick(self, controlID):

        if controlID == HOME_BUTTON:
            windowopen = False
            self.close()

        if controlID == BACK_BUTTON:
            windowopen = False
            self.close()

        if controlID == TUNE_DOWN:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "tune_down")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == TUNE_UP:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "tune_up")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == SEEK_DOWN:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "seek_down")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == SEEK_UP:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "seek_up")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == VOLUME_UP:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "volume_plus")
            time.sleep(0.3)
	    self.setFocus(self.buttonfocus)

        if controlID == VOLUME_DOWN:
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
                xbmc.Player().stop()
                CarpcController_SendCommand("system_mode_toggle")

            Radio_SendCommand(self, "volume_minus")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == MUTE_BUTTON:
	    global mute	    
            if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "false":
        	xbmc.Player().stop()
    	        CarpcController_SendCommand("system_mode_toggle")

	    Radio_Mute(self)
            windowopen = False
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STORE_BUTTON:
            windowopen = False
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == DELETE_BUTTON:
            windowopen = False
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STATIONS_BUTTON:
            windowopen = False
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == SETTINGS_BUTTON:
            windowopen = False
	    addon.openSettings()
	    Init_Values()
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA1_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station1")
	    Cleanup_Station(self, "Station1")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA2_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station2")
	    Cleanup_Station(self, "Station2")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA3_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station3")
	    Cleanup_Station(self, "Station3")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA4_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station4")
	    Cleanup_Station(self, "Station4")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA5_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station5")
	    Cleanup_Station(self, "Station5")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA6_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station6")
	    Cleanup_Station(self, "Station6")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA7_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station7")
	    Cleanup_Station(self, "Station7")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA8_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station8")
	    Cleanup_Station(self, "Station8")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA9_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station9")
	    Cleanup_Station(self, "Station9")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

        if controlID == STA10_BUTTON:
            windowopen = False
	    Tune_Station(self, "Station10")
	    Cleanup_Station(self, "Station10")
            time.sleep(0.3)
            self.setFocus(self.buttonfocus)

    def onFocus(self, controlID):
        pass
    
    def onControl(self, controlID):
        pass
 
fmdialog = radiofm("radiofm.xml", addonpath, 'default', '720')
t1 = Thread( target=updateWindow)
t1.setDaemon( True )
t1.start()
    
fmdialog.doModal()
del fmdialog


