import xbmc
import xbmcgui
import xbmcaddon
import socket
import time

# Get global paths
addon = xbmcaddon.Addon()
addonpath = addon.getAddonInfo('path').decode("utf-8")

# Open socket for communication with the gpio-manager UDP server
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

def CarpcController_SendCommand(command):
        UDP_IP = "127.0.0.1"
        UDP_PORT = 5005

        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

        # Send request to server
        sock.sendto(command + "\0", (UDP_IP, UDP_PORT))

while True:
    if str(xbmcgui.Window(10000).getProperty('Radio.Active')) == "true" and str(xbmc.getCondVisibility('Player.HasMedia')) == "1":
    	#xbmc.Player().stop()
    	CarpcController_SendCommand("system_mode_toggle")
	#xbmcgui.Window(10000).setProperty('Radio.Active')) == "false"
        # give us a break
    time.sleep(1.0)
